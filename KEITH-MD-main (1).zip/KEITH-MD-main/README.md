  <a href="https://keithsite.vercel.app"><img src="https://files.catbox.moe/07dmp1.jpg" alt="01" border="0" /></a>                     
## fork our repository [fork](https://github.com/Keithkeizzah/KEITH-MD/fork)
## visit this site to deploy [keith md](https://keithsite.vercel.app/keithmd)
                  
### Note
- when deploying via panel always edit your variables in set.env 


 - heroku deployment fixed 
   ## what's to be added??
   - updating more cool command
   ## what's fixed??
   - fixed lid issues
   - cleaned all errors and reducing bot storage weight for panel users
 
### 95% of this bot plugins are highly maintained by keith apis
 [explore apis keith](https://apiskeith.vercel.app/)
 
### this site is considered as a option b everything you need on bot is in this site
[keith site](https://keithsite.vercel.app/)
## keith site apk 
[download keithsite apk](https://keithsite.vercel.app/legit.apk)
 
   ## 🗿
- Updates will be synced remotically .
